

export const environment = {
  production: false,
  AWS_BUCKET_NAME : "ulearn-projectmanagement",
  AWS_BUCKET_REGION : "Asia Pacific (Mumbai) ap-south-1",
  ACCESS_KEY : "AKIAVTRZLNEN7H5PUEXS",
  SECRET_ACCESS_KEY : "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",
 }
  

  
