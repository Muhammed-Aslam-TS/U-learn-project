export const environment = {
  production: true,
  AWS_BUCKET_NAME : "",
  AWS_BUCKET_REGION : "",
  ACCESS_KEY : "",
  SECRET_ACCESS_KEY : "",
  };
  