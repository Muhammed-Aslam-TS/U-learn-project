export interface addCourseInterface {
    date: Date,
    plan1 : number,
    plan2 : number,
    plan3 : number,
    courseName:string,
    file:ImageBitmap
}